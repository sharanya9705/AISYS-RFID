# AISYS Library RFID Prototype

This repository contains a working prototype for the AISYS RFID-enabled library system described in the project SOP.

## Included modules
- FastAPI backend: main.py
- migration utility: migration_engine.py
- Streamlit dashboard: streamlit_app.py
- automated tests: test_solution.py

## Documentation
The project documentation folder contains:
- requirements traceability matrix
- architecture package
- test evidence
- deployment guide
- administration guide
- user guide
- rollback and restore runbook
- software bill of materials
- production readiness backlog

## Local run
```powershell
cd C:\Users\shara\OneDrive\Desktop\PROJECTS\AISYS\aisys-library-system
py -m pip install -r requirements.txt
py -m uvicorn main:app --host 127.0.0.1 --port 8001 --reload
streamlit run streamlit_app.py
```

## Verification
```powershell
cd C:\Users\shara\OneDrive\Desktop\PROJECTS\AISYS\aisys-library-system
pytest -q
```

## Current status
The prototype has working evidence for the core acceptance scenarios, but it remains a prototype rather than a fully production-ready SOP package.
